function validarFormulario() {
    let errores = [];

    // Validar RUT (Requerido)
    const rut = document.getElementById('rut').value;
    if (rut.length < 8) errores.push("El RUT es obligatorio.");

    // Validar Email (Estructura correcta)
    const email = document.getElementById('email').value;
    if (!email.includes("@") || !email.includes(".")) {
        errores.push("El email debe tener un formato válido.");
    }

    // Validar CV (docx o pdf)
    const cv = document.getElementById('cv').files[0];
    if (cv) {
        const ext = cv.name.split('.').pop().toLowerCase();
        if (ext !== 'pdf' && ext !== 'docx') {
            errores.push("El CV debe ser PDF o DOCX.");
        }
    }

    // Validar Contraseñas
    const p1 = document.getElementById('pass1').value;
    const p2 = document.getElementById('pass2').value;
    const passReg = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,12}$/;

    if (!passReg.test(p1)) {
        errores.push("La contraseña no cumple con los requisitos de seguridad.");
    }
    if (p1 !== p2) {
        errores.push("Las contraseñas no coinciden.");
    }

    // Mostrar resultados
    if (errores.length > 0) {
        alert("Errores:\n" + errores.join("\n"));
    } else {
        alert("¡Formulario enviado con éxito!");
    }
}

function limpiarFormulario() {
    document.getElementById('registroForm').reset();
}